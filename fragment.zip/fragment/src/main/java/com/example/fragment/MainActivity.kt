package com.example.fragment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Message
import android.widget.Toast
import com.example.fragment.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout

class MainActivity : AppCompatActivity() {
    lateinit var oneFragment: OneFragment
    lateinit var twoFragment: TwoFragment
    lateinit var threeFragment: ThreeFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val oneFragment = OneFragment()
        val twoFragment = TwoFragment()
        val threeFragment = ThreeFragment()

        supportFragmentManager.beginTransaction()
            .replace(R.id.layout_frame, oneFragment)
            .commit()

        //탭레이아웃에 메뉴를 입력
        val tab1: TabLayout.Tab = binding.tabLayout.newTab()
        tab1.text = "frg01"
        val tab2: TabLayout.Tab = binding.tabLayout.newTab()
        tab1.text = "frg02"
        val tab3: TabLayout.Tab = binding.tabLayout.newTab()
        tab1.text = "frg03"


        binding.tabLayout.addTab(tab1)
        binding.tabLayout.addTab(tab2)
        binding.tabLayout.addTab(tab3)

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(data: TabLayout.Tab?) {
                when (data?.text) {
                    "frg01" -> {
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.layout_frame, oneFragment)
                            .commit()
                    }
                    "frg02" ->{
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.layout_frame, twoFragment)
                            .commit()
                    }
                    "frg03" ->{
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.layout_frame, threeFragment)
                            .commit()
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
            }
        })
        fun openTwoFragment(data: String) {
            when (data) {
                "frg01" -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.layout_frame, oneFragment)
                        .commit()
                }
                "frg02" ->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.layout_frame, twoFragment)
                        .commit()
                }
                "frg03" ->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.layout_frame, threeFragment)
                        .commit()
                }
            }
        }
        //이벤트 설정
//        binding.btnFrame1.setOnClickListener{
//            //메인 엑티비티의 프레임레이아웃에 특정 프래그먼트를 설정하고 싶을때는 프래그먼트메니저가 필요
//            //트랜젝션 시작
//            val bundle = Bundle()
//            bundle.putString("key","메인화면데이터 르누아르 작품")
//            oneFragment.arguments = bundle
//            supportFragmentManager.beginTransaction()
//                .replace(R.id.layout_frame,oneFragment)
//                .commit()
//            Toast.makeText(applicationContext,"One fragment display", Toast.LENGTH_SHORT).show()
//        }
//        binding.btnFrame2.setOnClickListener{
//            //메인 엑티비티의 프레임레이아웃에 특정 프래그먼트를 설정하고 싶을때는 프래그먼트메니저가 필요
//            //트랜젝션 시작
//            val bundle = Bundle()
//            bundle.putString("key","메인화면데이터 또또 르누아르 작품")
//            twoFragment.arguments = bundle
//            supportFragmentManager.beginTransaction()
//                .replace(R.id.layout_frame,twoFragment)
//                .commit()
//            Toast.makeText(applicationContext,"Two fragment display", Toast.LENGTH_SHORT).show()
//        }

    }

//    fun openTwoFragment(message: String){
//        val bundle = Bundle()
//        bundle.putString("key","메인화면데이터 르누아르 작품")
//        oneFragment.arguments = bundle
//        supportFragmentManager.beginTransaction()
//            .replace(R.id.layout_frame,oneFragment)
//            .commit()
//        Toast.makeText(applicationContext,"One fragment display", Toast.LENGTH_SHORT).show()
//    }

}